def my_func():
	return false
